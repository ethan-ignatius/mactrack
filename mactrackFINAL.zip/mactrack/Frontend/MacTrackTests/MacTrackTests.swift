//
//  MacTrackTests.swift
//  MacTrackTests
//
//  Created by Ethan Ignatius on 2024-09-28.
//

import Testing
@testable import MacTrack

struct MacTrackTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
